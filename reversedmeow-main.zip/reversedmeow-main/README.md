# rmtrollbox
1) don't put ip-loggers here.
2) **Apply changes to both client.html and client-adm.html**
3) **dont overwrite the client-adm.html with client.html or client.html with client-adm.html**
